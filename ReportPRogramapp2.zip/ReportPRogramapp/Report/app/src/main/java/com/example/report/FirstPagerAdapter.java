package com.example.report;

import androidx.annotation.NonNull;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentActivity;
import androidx.viewpager2.adapter.FragmentStateAdapter;

public class FirstPagerAdapter extends FragmentStateAdapter {

    int[] colors = {
            0xFFAB63C9,
            0xFFFF4040,
            0xFF669900,
            0xFFFF9800,
            0xFF29B6D2,
            0xFF00BCD4
    };

    public FirstPagerAdapter(@NonNull FragmentActivity activity) {
        super(activity);
    }

    @NonNull
    @Override
    public Fragment createFragment(int position) {
        return ColorFragment.newInstance(
                position,
                colors[position],
                (position + 1) + " Page"
        );
    }

    @Override
    public int getItemCount() {
        return colors.length;
    }
}
