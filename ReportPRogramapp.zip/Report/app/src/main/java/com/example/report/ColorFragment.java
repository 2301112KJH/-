package com.example.report;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.FrameLayout;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;

public class ColorFragment extends Fragment {

    public static ColorFragment newInstance(
            int page, int color, String text) {

        ColorFragment fragment = new ColorFragment();

        Bundle args = new Bundle();
        args.putInt("color", color);
        args.putString("text", text);

        fragment.setArguments(args);

        return fragment;
    }

    @Nullable
    @Override
    public View onCreateView(
            @NonNull LayoutInflater inflater,
            @Nullable ViewGroup container,
            @Nullable Bundle savedInstanceState) {

        View view = inflater.inflate(
                R.layout.fragment_color,
                container,
                false
        );

        Bundle args = getArguments();

        int color = args.getInt("color");
        String textValue = args.getString("text");

        FrameLayout layout = (FrameLayout) view;
        layout.setBackgroundColor(color);

        TextView text = view.findViewById(R.id.pageText);
        text.setText(textValue);

        return view;
    }
}