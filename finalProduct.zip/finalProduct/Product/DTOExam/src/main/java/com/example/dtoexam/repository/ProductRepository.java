package com.example.dtoexam.repository;

import com.example.dtoexam.domain.Product;
import org.springframework.data.jpa.repository.JpaRepository;

// Product Entity의 데이터베이스 접근을 담당하는 인터페이스
// JpaRepository<Product, Long>
// Product : 관리할 Entity
// Long : Product의 기본키인 id의 자료형
//
// Spring Data JPA가 기본 CRUD 기능을 자동으로 제공
public interface ProductRepository
        extends JpaRepository<Product, Long> {

}