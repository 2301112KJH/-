import react from '@vitejs/plugin-react'
import { defineConfig } from 'vite'

// https://vite.dev/config/
export default defineConfig({
  plugins: [react()],
  //개발 서버의 프록시 설정
  server:{
    proxy:{
      '/events':{
        target:'http://localhost:3000',
        changeOrigin:true
      }
    }
  }
})
// '/events로 시작하는 요청을 전달
//target: 실제 요청을 처리할 express 서버
//changeOrigin: 백엔드로 전달하는 요청의 host 헤더를 변경