import './App.css'
import {useEffect, useState} from "react";
function App() {
    //const events = [{ id: 1, title: 'AI 특강', capacity: 30 }]
    const [events, setEvents] = useState([])
    const [eventTitle, setEventTitle] = useState("")
    const [capacity, setCapacity] = useState("")
    const [editingId, setEditingId]= useState(null)
    // ① GET 실습
    useEffect(() => {
        fetch('/events')
            .then(response => {
                if (!response.ok) {
                    throw new Error('목록 조회 실패')
                }
                return response.json()
            })
            .then(data => {
                setEvents(data)
            })
            .catch((error) => {
                console.error(error)
            })
    },[])
    // ② POST 실습에서 입력창의 상태 추가
    async function addEvent(e) {
        e.preventDefault()
        const title = eventTitle.trim()
        const numberCapacity = Number(capacity)
        if (title===''||capacity.trim()===''||!Number.isInteger(numberCapacity)||numberCapacity<=0) {
            alert("올바른 행사 정보나 정보를 입력하세요")
            return
        }
        try{
            const response = await fetch('/events', {
                method: 'POST',
                headers: {'Content-Type': 'application/json'},
                body: JSON.stringify({
                    title: title,
                    capacity: numberCapacity
                })

            })
            const data = await response.json()
            if (!response.ok) {
                throw new Error(data.message || '행사 등록 실패')
            }
            setEvents(preEvents => [...preEvents, data])
            setEventTitle("")
            setCapacity("")
        }catch(error){
            console.error(error)
            alert(error.message)
        }
    }

    // ③ DELETE 실습에서 이 위치에 deleteEvent(id)를 작성한다.
    async function deleteEvent(id) {
        if (!window.confirm('이 행사를 삭제하시겠습니까?')){
            return
        }
        try{
            const response = await fetch(`/events/${id}`, {method: 'DELETE'})
            const data = await response.json()
            if (!response.ok) {
                throw new Error(data.message || '삭제 실패')
            }
            setEvents(preEvents => preEvents.filter(event => event.id !== id))
        }catch(error){
            console.error(error)
            alert(error.message)
        }
    }

    // ④ PUT 실습에서 수정할 행사 ID 상태 추가
    function startEdit(event){
        setEditingId(event.id)
        setEventTitle(event.title)
        setCapacity(event.capacity)
    }
    async function updateEvent(e) {
        e.preventDefault()
        const title = eventTitle.trim()
        const numberCapacity = Number(capacity)
        if (title === '' || capacity.trim() === '' || !Number.isInteger(numberCapacity) || numberCapacity <= 0) {
            alert("올바른 행사 정보나 정보를 입력하세요")
            return
        }
        try {
            const response = await fetch(`/events/${editingId}`, {
                method: "PUT",
                headers: {'Content-Type': 'application/json'},
                body: JSON.stringify({
                    title,
                    capacity: numberCapacity
                })
            })
            const data = await response.json()
            if (!response.ok) {
                throw new Error(data.message || '수정 실패')
            }
            setEvents(preEvents =>
                preEvents.map(event => event.id === editingId ? data : event))
            setEditingId(null)
            setEventTitle('')
            setCapacity('')
        } catch (error) {
            console.error(error)
            alert(error.message)
        }
    }
        return (
            <div className="app">
                <header className="app-header">
                    <h1>행사 관리 시스템</h1>
                    <p>React + Express REST API 실습</p>
                    <div className="event-banner-placeholder">
                        <img
                            className="event-banner"
                            src="/images/event-banner.jpg"
                            alt="행사 안내 배너"/>
                    </div>
                    {/*public 우클릭 → 새로 만들기(New) → 디렉터리(Directory) → images 입력->jpg*/}
                </header>

                <section className="panel">
                    <div className="list-heading">
                        <h2 className="panel-title">행사 목록</h2>
                        <span className="count">총 {/*목록의 총 횟수*/}건</span>
                    </div>

                    <ul className="event-list">
                        {events.map((event) => (
                            <li key={event.id} className="event-item">
                                <div className="event-info">
                                    <p className="event-title">{event.title}</p>
                                    <span className="event-meta">
                  번호 {event.id} · 정원 {event.capacity}명
                </span>
                                </div>

                                <div className="event-actions">
                                    {/* 수정 버튼의 onClick에 클릭 핸들러를 연결하세요.   버튼을 클릭하면 수정 시작 함수에 현재 행사(event)를 전달하세요. */}
                                    <button type="button" className="btn btn-secondary btn-small"
                                            onClick={() => startEdit(event)}>
                                        수정
                                    </button>

                                    {/* 현재 행의 ID(event.id)가 수정 중인 행사 ID와 같을 때만 취소 버튼을 표시하세요.
                                    취소 버튼을 누르면 cancelEdit 함수가 실행되도록 onClick을 추가하세요. */}
                                    <button type="button" className="btn btn-secondary btn-small">
                                        취소
                                    </button>

                                    {/* 삭제 버튼에 onClick을 추가하세요.  클릭하면 삭제 함수에 현재 행사의 ID를 전달하세요.  */}
                                    <button type="button" className="btn btn-danger btn-small"
                                            onClick={() => {
                                                deleteEvent(event.id)
                                            }}>
                                        삭제
                                    </button>
                                </div>
                            </li>
                        ))}
                    </ul>
                </section>


                <section className="panel">
                    <h2 className="panel-title">행사 등록</h2>
                    {/* POST 실습 : 폼을 제출하면 addEvent 함수가 실행되도록 아래 <form>의 onSubmit을 수정하세요.*/}
                    {/* PUT 실습:  editingId 값에 따라 실행할 함수를 선택하도록 같은 onSubmit을 다시 수정하세요.
        editingId가 null이면 addEvent를 연결하세요. editingId에 행사 ID가 있으면 updateEvent를 연결하세요. */}
                    <form className="event-form" onSubmit={editingId === null ? addEvent : updateEvent}>
                        <div className="field">
                            <label htmlFor="event-title">행사 제목</label>

                            {/* POST 실습 — 행사 제목 입력칸을 React 상태와 연결하세요.
                      1. value 속성을 추가해 eventTitle의 값을 입력칸에 표시하세요.
                      2. onChange 속성을 추가해 사용자가 입력할 때마다  새 입력값을 setEventTitle로 저장하세요.
                      힌트는 이벤트 객체의 target.value에서 새 입력값을 읽는 것입니다.*/}
                            <input
                                id="event-title"
                                type="text"
                                placeholder="행사 제목 입력"
                                value={eventTitle}
                                onChange={(e) => setEventTitle(e.target.value)}
                            />
                        </div>

                        <div className="field">
                            <label htmlFor="event-capacity">정원</label>

                            {/*  POST 실습 — 정원 입력칸을 React 상태와 연결하세요.
                         1. value 속성을 추가해 capacity의 값을 입력칸에 표시하세요.
                         2. onChange 속성을 추가해 사용자가 입력할 때마다
                          새 입력값을 setCapacity로 저장하세요.   힌트는 이벤트 객체의 target.value에서 새 입력값을 읽는 것입니다.*/}
                            <input
                                id="event-capacity"
                                type="number"
                                min="1"
                                placeholder="정원 입력"
                                value={capacity}
                                onChange={(e) => setCapacity(e.target.value)}
                            />
                        </div>

                        <button type="submit" className="btn btn-primary">
                            {/*  PUT 실습 — 수정 상태에 따라 버튼에 표시할 글자를 바꾸세요.
                         1. editingId가 null이면 '등록'을 표시하세요.
                         2. editingId에 행사 ID가 있으면 '수정 완료'를 표시하세요.
                        힌트는 JSX의 중괄호 안에서 삼항 연산자(? :)를 사용하는 것입니다.
                        */}
                            {editingId === null ? '등록' : '수정완료'}
                        </button>
                    </form>
                </section>

                {/* 행사 1건 조회 영역 */}
                <section className="panel">

                    <h2 className="panel-title">행사 1건 조회</h2>

                    <div className="search-form">

                        <div className="field">

                            <label htmlFor="search-id">행사 ID</label>

                            <input
                                id="search-id"
                                type="number"
                                min="1"
                                placeholder="행사 ID 입력"

                                // 문제 1. 입력창에 searchId 상태값이 표시되도록
                                // value 속성을 추가하세요.

                                // 문제 2. 사용자가 ID를 입력하면
                                // setSearchId로 입력값을 저장하도록
                                // onChange 이벤트 핸들러를 추가하세요.
                            />

                        </div>

                        <button
                            type="button"
                            className="btn btn-primary"

                            // 문제 3. 조회 버튼을 클릭하면
                            // findEvent 함수가 실행되도록
                            // onClick 이벤트 핸들러를 추가하세요.
                        >
                            조회
                        </button>

                    </div>

                    {/* 문제 4. selectedEvent에 조회 결과가 있을 때만
        아래 결과 영역이 표시되도록 조건부 렌더링을 구현하세요.
        아직 조회 결과가 없으면 결과 영역을 표시하지 않습니다. */}

                    {/* TODO: 이 위치에 조건부 렌더링의 시작 부분 작성 */}

                    <div className="search-result">

                        {/* 문제 5. 조회한 행사의 ID를 출력하세요. */}
                        <p><strong>ID:</strong> {/* TODO */}</p>

                        {/* 문제 6. 조회한 행사의 제목을 출력하세요. */}
                        <p><strong>행사 제목:</strong> {/* TODO */}</p>

                        {/* 문제 7. 조회한 행사의 정원을 출력하세요. */}
                        <p><strong>정원:</strong> {/* TODO */}명</p>

                    </div>

                    {/* TODO: 이 위치에 조건부 렌더링의 끝 부분 작성 */}

                </section>


            </div>
        )
}
//async function getNumber(){return 10}
//const result = getNumber()
//console.log(result)
//async function loadEvents(){ console.log('서버실행')
//const res = await fetch('http://localhost:3000/events')
//console.log('응답도착')
// }
//loadEvents(); console.log('함수밖 실행')
//async function getNumber(){return 10}
//getNumber().then((value)=> console.log(value))
//fetch()는 http요청을 비동기로 시작하고 Promise를 돌려줌
//async는 함수의 결과를 Promise로 돌려줌,함수 본문은 호출되자마자 실행
//await Promise의 결과가 준비가 될때까지 그 지점 이후의 실행을 잠시 멈춘다.
export default App