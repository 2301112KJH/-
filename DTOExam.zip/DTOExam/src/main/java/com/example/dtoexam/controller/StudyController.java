package com.example.dtoexam.controller;


import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;

@Controller
public class StudyController {
    @GetMapping("/study/new")
    public String showStudyForm() {
        return "study-form";
    }
}
