package com.example.dtoexam.service;

import com.example.dtoexam.domain.Product;
import com.example.dtoexam.dto.ProductForm;
import com.example.dtoexam.repository.ProductRepository;
import org.springframework.data.domain.Sort;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class ProductService {

    private final ProductRepository productRepository;

    public ProductService(ProductRepository productRepository) {
        this.productRepository = productRepository;
    }

    public void save(ProductForm productForm) {

        Product product = new Product(
                null,
                productForm.getTitle(),
                productForm.getPrice(),
                0,
                productForm.getCategory(),
                true
        );

        productRepository.save(product);
    }

    // 상품 목록 조회 및 가격 정렬
    public List<Product> findAll(String sort) {

        if ("low".equals(sort)) {
            return productRepository.findAll(Sort.by(Sort.Direction.ASC, "price"));
        }

        if ("high".equals(sort)) {
            return productRepository.findAll(Sort.by(Sort.Direction.DESC, "price"));
        }

        return productRepository.findAll();
    }
}
