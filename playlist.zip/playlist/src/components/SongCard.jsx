function SongCard({song}){
    return(
        <div className="song-card">
            <div className="song-info">
                <h3>{song.title}</h3>
                <p>{song.artist}</p>
                <span>{song.genre}</span>
            </div>
        <button type="button" className="like_btn"
                onClick={()=> onToggleLike(song.id)}>
            {song.liked? '👍':'👎'}
        </button>
    </div>
    )
}
export default SongCard
//다른 파일에서 SongCard를 사용할 수 있도록 기본 내보내기