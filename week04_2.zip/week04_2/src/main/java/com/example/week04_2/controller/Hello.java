package com.example.week04_2.controller;

import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class Hello {
    @GetMapping("/hello")
    public String hello(){
        return "Hello Natenyahu";
    }



    @GetMapping("/welcome")
    public String welcome(@RequestParam(name = "name", defaultValue = "Epstein") String name){
        return name + "님, welcome!";
    }

    @GetMapping("/welcomeHi")
    public String welcomeHi(@RequestParam(name = "name", defaultValue = "Epstein") String name,
                            @RequestParam(name = "category", defaultValue = "kidnapping") String category
                            ){
        return name + "님이 "+category+"에 접속하셨읍니다.";
    }

}
