package com.example.report;

import androidx.annotation.NonNull;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentActivity;
import androidx.viewpager2.adapter.FragmentStateAdapter;

public class TabPagerAdapter extends FragmentStateAdapter {

    public TabPagerAdapter(@NonNull FragmentActivity activity) {
        super(activity);
    }

    @NonNull
    @Override
    public Fragment createFragment(int position) {

        Fragment fragment = null;

        switch (position) {
            case 0:
                fragment = ColorFragment.newInstance(
                        0, 0xFF8BC34A, "HOME");
                break;

            case 1:
                fragment = ColorFragment.newInstance(
                        1, 0xFF03A9F4, "CHATTING");
                break;

            case 2:
                fragment = ColorFragment.newInstance(
                        2, 0xFFFFC107, "NEWS");
                break;

            case 3:
                fragment = ColorFragment.newInstance(
                        3, 0xFF9C27B0, "SETTING");
                break;
        }

        return fragment;
    }

    @Override
    public int getItemCount() {
        return 4;
    }
}