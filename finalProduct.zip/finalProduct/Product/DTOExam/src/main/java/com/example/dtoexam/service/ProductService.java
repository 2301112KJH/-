package com.example.dtoexam.service;

import com.example.dtoexam.domain.Product;
import com.example.dtoexam.dto.ProductForm;
import com.example.dtoexam.repository.ProductRepository;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class ProductService {

    private final ProductRepository productRepository;

    public ProductService(ProductRepository productRepository) {
        this.productRepository = productRepository;
    }

    public void save(ProductForm productForm) {

        Product product = new Product(
                null,
                productForm.getTitle(),
                productForm.getPrice(),
                0,
                productForm.getCategory(),
                true
        );

        productRepository.save(product);
    }

    public List<Product> findAll() {
        return productRepository.findAll();
    }
}