package com.example.report;

import android.os.Bundle;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;
import android.content.res.ColorStateList;
import android.graphics.Color;
import android.text.InputType;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

public class MainActivity extends AppCompatActivity {

    Button btnAlert, btnInput, btnList;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        getWindow().clearFlags(
                WindowManager.LayoutParams.FLAG_FULLSCREEN
        );

        setContentView(R.layout.activity_main);

        if (getSupportActionBar() != null) {
            getSupportActionBar().show();
            getSupportActionBar().setTitle("Report2");
        }

        btnAlert = findViewById(R.id.btnAlert);
        btnInput = findViewById(R.id.btnInput);
        btnList = findViewById(R.id.btnList);

        btnAlert.setOnClickListener(v -> {
            new AlertDialog.Builder(MainActivity.this)
                    .setIcon(R.drawable.sharp_add_alert_24)
                    .setTitle("알림")
                    .setMessage("이번주 레포트는 Dialog 입니다")
                    .setPositiveButton("확인", (dialog, which) ->
                            showToast("확인했습니다"))
                    .show();
        });

        btnInput.setOnClickListener(v -> {
            EditText editText = new EditText(MainActivity.this);
            editText.setHint("");
            editText.setBackgroundTintList(
                    ColorStateList.valueOf(Color.rgb(255, 64, 129))
            );

            new AlertDialog.Builder(MainActivity.this)
                    .setTitle("이름 입력")
                    .setView(editText)
                    .setNegativeButton("CANCEL", (dialog, which) -> {})
                    .setPositiveButton("OK", (dialog, which) -> {
                        String name = editText.getText()
                                .toString().trim();

                        if (name.isEmpty()) {
                            showToast("입력해주세요");
                        } else {
                            showToast(name);
                        }
                    })
                    .show();
        });

        btnList.setOnClickListener(v -> showStudentIdDialog());
    }

    private void showStudentIdDialog() {
        EditText editText = new EditText(MainActivity.this);
        editText.setInputType(InputType.TYPE_CLASS_NUMBER);
        editText.setBackgroundTintList(
                ColorStateList.valueOf(Color.rgb(255, 64, 129))
        );

        new AlertDialog.Builder(MainActivity.this)
                .setTitle("학번 입력")
                .setView(editText)
                .setNegativeButton("CANCEL", (dialog, which) -> {})
                .setPositiveButton("OK", (dialog, which) -> {
                    String input = editText.getText()
                            .toString().trim();

                    if (input.isEmpty()) {
                        showToast("학번을 입력해주세요");
                        return;
                    }

                    try {
                        int studentId = Integer.parseInt(input);

                        if (studentId % 2 == 0) {
                            showGradeDialog();
                        } else {
                            showHobbyDialog();
                        }
                    } catch (NumberFormatException e) {
                        showToast("올바른 학번을 입력해주세요");
                    }
                })
                .show();
    }

    private void showGradeDialog() {
        String[] grades = {
                "1학년", "2학년", "3학년", "4학년"
        };

        int[] selected = {-1};

        new AlertDialog.Builder(MainActivity.this)
                .setIcon(R.drawable.baseline_brightness_6_24)
                .setTitle("몇학년 입니까?")
                .setSingleChoiceItems(
                        grades,
                        -1,
                        (dialog, which) -> selected[0] = which
                )
                .setPositiveButton("닫기", (dialog, which) -> {
                    if (selected[0] != -1) {
                        int grade = selected[0] + 1;
                        showToast("선택한 학년 : " + grade + " 학년");
                    } else {
                        showToast("학년을 선택해주세요");
                    }
                })
                .show();
    }

    private void showHobbyDialog() {
        String[] hobbies = {
                "독서", "등산", "수영", "수집", "영화"
        };

        boolean[] checked = new boolean[hobbies.length];

        new AlertDialog.Builder(MainActivity.this)
                .setTitle("당신의 취미는?")
                .setMultiChoiceItems(
                        hobbies,
                        checked,
                        (dialog, which, isChecked) ->
                                checked[which] = isChecked
                )
                .setPositiveButton("닫기", (dialog, which) -> {
                    StringBuilder result = new StringBuilder();

                    for (int i = 0; i < hobbies.length; i++) {
                        if (checked[i]) {
                            if (result.length() > 0) {
                                result.append(", ");
                            }
                            result.append(hobbies[i]);
                        }
                    }

                    if (result.length() > 0) {
                        showToast("취미 : " + result);
                    } else {
                        showToast("취미를 선택해주세요");
                    }
                })
                .show();
    }

    private void showToast(String message) {
        Toast.makeText(
                MainActivity.this,
                message,
                Toast.LENGTH_SHORT
        ).show();
    }
}