package com.example.week04_2;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Week042Application {

    public static void main(String[] args) {
        SpringApplication.run(Week042Application.class, args);
    }

}
