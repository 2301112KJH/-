package com.example.week05.controller;

import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class HelloController {
    @GetMapping("/hello")
    public String hello() {
        return "Hello World!";
    }

    @GetMapping("/")
    public String hi() {
        return "서버 시작";
    }

    @GetMapping("/welcome")
    public String welcome(@RequestParam(name = "name",defaultValue = name) String name) {
        // name : @RequestParam 어노테이션 이름
        //"name: : (브라우저가 보낸 요청 파라미터 이름)
        //String name : 자바의 name 변수의 이름.
        return name + "님 환영합니다.";
    }
    @GetMapping("/welcomeHi")
    public String welcomeHi(@RequestParam(name = "name") String name,
                            @RequestParam(name = "category") String category) {
        return name + "님이" + category + "에 접속하셨습니다.";
    }
}
