
package com.example.report;

import androidx.annotation.NonNull;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentActivity;
import androidx.viewpager2.adapter.FragmentStateAdapter;

public class TabPagerAdapter extends FragmentStateAdapter {

    public TabPagerAdapter(@NonNull FragmentActivity activity) {
        super(activity);
    }

    @NonNull
    @Override
    public Fragment createFragment(int position) {

        switch (position) {

            case 0:
                return ColorFragment.newInstance(
                        0, 0xFF8BC34A, "HOME");

            case 1:
                return ColorFragment.newInstance(
                        1, 0xFFFFC0A5, "CHATTING");

            case 2:
                return ColorFragment.newInstance(
                        2, 0xFF2196F3, "NEWS");

            case 3:
                return ColorFragment.newInstance(
                        3, 0xFF2196F3, "SETTING");

            default:
                return ColorFragment.newInstance(
                        0, 0xFF8BC34A, "HOME");
        }
    }

    @Override
    public int getItemCount() {
        return 4;
    }
}
