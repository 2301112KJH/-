package com.example.week04_2;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Week042ApplicationTests {

    @Test
    void contextLoads() {
    }

}
