package com.example.report;

import android.graphics.Color;
import android.os.Bundle;
import android.view.Gravity;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;

public class ColorFragment extends Fragment {

    public static ColorFragment newInstance(
            int page, int color, String text) {

        ColorFragment fragment = new ColorFragment();

        Bundle args = new Bundle();
        args.putInt("color", color);
        args.putString("text", text);

        fragment.setArguments(args);

        return fragment;
    }

    @Nullable
    @Override
    public View onCreateView(
            @NonNull LayoutInflater inflater,
            @Nullable ViewGroup container,
            @Nullable Bundle savedInstanceState) {

        Bundle args = getArguments();

        int color = args.getInt("color");
        String textValue = args.getString("text", "");

        if ("SETTING".equals(textValue)) {

            LinearLayout layout = new LinearLayout(requireContext());
            layout.setOrientation(LinearLayout.VERTICAL);
            layout.setBackgroundColor(color);

            String[] names = {
                    "홍길동",
                    "이대한",
                    "한민국",
                    "이윤지"
            };

            for (String name : names) {

                TextView item = new TextView(requireContext());

                item.setText(name);
                item.setTextSize(20);
                item.setTextColor(Color.BLACK);
                item.setGravity(Gravity.CENTER_VERTICAL);
                item.setPadding(30, 20, 20, 20);
                item.setBackgroundColor(color);

                LinearLayout.LayoutParams params =
                        new LinearLayout.LayoutParams(
                                ViewGroup.LayoutParams.MATCH_PARENT,
                                ViewGroup.LayoutParams.WRAP_CONTENT
                        );

                params.setMargins(8, 5, 8, 5);

                layout.addView(item, params);

                item.setOnClickListener(v -> {
                    Toast.makeText(
                            requireContext(),
                            name,
                            Toast.LENGTH_SHORT
                    ).show();
                });
            }

            return layout;
        }

        View view = inflater.inflate(
                R.layout.fragment_color,
                container,
                false
        );

        view.setBackgroundColor(color);

        TextView text = view.findViewById(R.id.pageText);
        text.setText(textValue);

        return view;
    }
}
