
package com.example.dtoexam.service;

import com.example.dtoexam.domain.Product;
import com.example.dtoexam.dto.ProductForm;
import com.example.dtoexam.repository.ProductRepository;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class ProductService {

    private final ProductRepository productRepository;

    // Repository 생성자 주입
    public ProductService(ProductRepository productRepository) {
        this.productRepository = productRepository;
    }

    // 상품 등록
    public void save(ProductForm productForm) {

        Product product = new Product(
                null,
                productForm.getTitle(),
                productForm.getPrice(),
                0,
                "미분류",
                true
        );

        productRepository.save(product);
    }

    // 상품 전체 조회
    public List<Product> findAll() {
        return productRepository.findAll();
    }
}
