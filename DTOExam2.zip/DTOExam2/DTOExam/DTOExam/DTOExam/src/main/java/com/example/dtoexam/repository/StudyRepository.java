package com.example.dtoexam.repository;

import com.example.dtoexam.domain.Study;
import org.springframework.data.jpa.repository.JpaRepository;

//java의 인터페이스 : 클래스가 어떤 기능을 제공해야 하는지 정해놓은 약속
//class : 그 기능이 실제로 어떻게 동작하게 되는지 구현
//StudyRepository : Study Entity의 db접근을 담당
//JpaRepository<Study, Long> : Study : 관리를 할 Entity, Long : Study id의 자료형
//-> Spring Data JPA가 CRUD 등의 기본 데이터베이스 작업을 제공
public interface StudyRepository extends JpaRepository<Study, Long> {
/*메서드를 직접 작성하지 않아도 Spring Data JPA가 아래의 기능등으로 자동으로 만들어줌
* save() : 저장 또는 변경
* findAll() : 전체 조회
* findById() : 특정 id를 조회
* deleteById() : 특정 id 삭제
* */
}
