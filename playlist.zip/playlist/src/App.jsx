import './App.css'
import SongCard from './components/SongCard'
import {useState} from 'react'
function App() {
    const [songs, setSongs]= useState([
        {id:1, title:"밤하늘", artist:'AAA', genre:'발라드', liked:false},
        {id:2, title:"새벽노을", artist:'BBB', genre:'댄스', liked:false},
        {id:3, title:"밤바다", artist:'CCC', genre:'인디', liked:false}
    ])
  const [selectedGenre, setselectedGenre]=useState('전체')
  const filterSongs=songs.filter(
      song => selectedGenre==='전체' || selectedGenre===song.genre
  )
  /*useState(): React가 제공하는 훅(hook)
  컴퍼넌트가 다시 랜더링되어도 상태를 기억하고, 호출하면
  [현재상태, 상태변경함수]를 돌려줌.
  */
  function toggleLike(id){
    setSongs(prevSongs =>
        prevSongs.map(song => song.id===id?  {...song, liked:!song.liked}  :  song  ))
  }

    return (
        <div className="app">
            <h1>My Playlist</h1>
            <div className="genre-filter">
              {['전체','발라드','댄스','인디'].map(
                  (genre)=>(
                      <button key={genre} type="button"
                      onClick={()=> setselectedGenre(genre)}
                      >{genre}</button>
                  )
              )

              }
            </div>
            <div className="song-list">
                {
                    filterSongs.map(
                        (song)=>(
                            <SongCard key={song.id} song={song} onToggleLike={toggleLike}/>
                        )
                    )
                }
                {/*
            map() : 배열에서 노래의 객체를 하나씩 꺼네오는 메서드
            <SongCard : 자식 컴포넌트에게 props를 넘겨즘
            key={song.id}: React가 목록 항목을 구분하기 위한 고유식별자
            song={song}: 현제 노래 객체를 song이라는 이름의 props로 전달
            */}
            </div>
        </div>
    )
}
export default App
/*
map() : 1. 배열에서 하나의 객체를 꺼냄
2. 화살표 함수에 전달.
3. 화살표 함수가 SongCard.jsx를 반환
4. 2,3번째 똑같다.
5. 이렇게 만들어진 jsx요소들을 새로운 배열로 반환
6. React가 반환된 배열을 이용해서 화면에 랜더링
*/