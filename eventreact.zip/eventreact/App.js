import { useState, useEffect} from 'react'
import './App.css'

function App() {
    const [events, setEvents]=useState([]) //현재 목록 표시
    const [eventTitle, setEventTitle]=useState('')
    const [capacity, setCapacity]=useState('')
    //useEffect(()=>{ },[]): 첫번째 인수- react가 실행할 함수,
    //두번째 인수 : 의존성 배열, []를 쓰면 컴포넌트가 화면에 처음
    //표시된 뒤 이 함수를 실행
    useEffect(()=>{
        fetch('./events') //vite 프록시를 통해 Get요청, fetch()는 서버에 http요청을 보내는 js 함수
            .then((response)=>{
                if(!response.ok){
                    throw new Error("행사 목록 조회 실패")
                }
                return response.json()
            })
            .then((data)=> {setEvents(data)} ) //서버에서 받은 행사 배열을 React의 상태에 저장
            .catch((error)=>{ //네트워크 오류나 처리중 발생한 오류
            console.error(error)
        })
        },[])

    return (
        <div className="app">

            {/* 행사 관리 화면 제목 */}
            <header className="app-header">
                <h1>행사 관리 시스템</h1>
                <p>React + Express REST API 실습</p>
            </header>

            {/* 행사 등록 영역 */}
            <section className="panel">
                <h2 className="panel-title">행사 등록</h2>

                <form className="event-form" onSubmit={editingId === null ? addEvent : updateEvent}>



                    {/* 행사 제목 입력 */}
                    <div className="field">
                        <label htmlFor="event-title">행사 제목</label>
                        <input
                            id="event-title"
                            type="text"
                            placeholder="행사 제목 입력"
                            value={eventTitle}

                        />
                    </div>

                    {/* 행사 정원 입력 */}
                    <div className="field">
                        <label htmlFor="event-capacity">정원</label>
                        <input
                            id="event-capacity"
                            type="number"
                            min="1"
                            placeholder="정원 입력"
                            value={capacity}

                        />
                    </div>

                    <button
                        type="submit"
                        className="btn btn-primary"
                    > {editingId === null ? '등록' : '수정 완료'}
                    </button>
                </form>
            </section>

            {/* 행사 목록 영역 */}
            <section className="panel">
                <div className="list-heading">
                    <h2 className="panel-title">행사 목록</h2>
                    <span className="count">
            총 건
          </span>
                </div>

                <ul className="event-list">

                    {/* 행사 배열을 JSX 목록으로 변환 */}
                    {events.map((event) => (
                        <li key={event.id} className="event-item">
                            <div className="event-info">
                                <p className="event-title">
                                    {event.title}
                                </p>
                                <span className="event-meta">

                </span>
                            </div>

                            <div className="event-actions">
                                <button
                                    type="button"
                                    className="btn btn-secondary btn-small"
                                >수정
                                </button>

                                {editingId !== null && (
                                    <button
                                        type="button"
                                        className="btn btn-secondary">
                                        취소</button>
                                )}


                                {/* DELETE 연동 후 활성화 */}
                                <button
                                    type="button"
                                    className="btn btn-danger btn-small"


                                > 삭제 </button>

                            </div>
                        </li>
                    ))}

                </ul>
            </section>
        </div>
    )
}

export default App
