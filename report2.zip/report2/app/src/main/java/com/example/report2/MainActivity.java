package com.example.report2;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.os.BatteryManager;
import android.os.Bundle;
import android.widget.ProgressBar;
import android.widget.TextView;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.content.ContextCompat;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

public class MainActivity extends AppCompatActivity {

    TextView tvInfo, tvLevel;
    ProgressBar pbLevel;
    int count = 0;

    BroadcastReceiver batteryReceiver = new BroadcastReceiver() {
        @Override
        public void onReceive(Context context, Intent intent) {
            if (!Intent.ACTION_BATTERY_CHANGED.equals(intent.getAction())) return;
            count++;

            int plugged = intent.getIntExtra(BatteryManager.EXTRA_PLUGGED, 0);
            String strPlugged;
            switch (plugged) {
                case BatteryManager.BATTERY_PLUGGED_AC:
                    strPlugged = "AC 어댑터"; break;
                case BatteryManager.BATTERY_PLUGGED_USB:
                    strPlugged = "USB"; break;
                case BatteryManager.BATTERY_PLUGGED_WIRELESS:
                    strPlugged = "무선 충전"; break;
                default:
                    strPlugged = "Battery"; break;
            }

            int status = intent.getIntExtra(BatteryManager.EXTRA_STATUS,
                    BatteryManager.BATTERY_STATUS_UNKNOWN);
            String strStatus;
            switch (status) {
                case BatteryManager.BATTERY_STATUS_CHARGING:
                    strStatus = "충전 중"; break;
                case BatteryManager.BATTERY_STATUS_DISCHARGING:
                    strStatus = "방전 중"; break;
                case BatteryManager.BATTERY_STATUS_FULL:
                    strStatus = "가득 충전"; break;
                case BatteryManager.BATTERY_STATUS_NOT_CHARGING:
                    strStatus = "충전 중 아님"; break;
                default:
                    strStatus = "알 수 없음"; break;
            }

            int level = intent.getIntExtra(BatteryManager.EXTRA_LEVEL, 0);
            int scale = intent.getIntExtra(BatteryManager.EXTRA_SCALE, 100);
            int percent = level * 100 / scale;

            tvInfo.setText("수신 회수 : " + count
                    + "\n연결 : " + strPlugged
                    + "\n상태 : " + strStatus);
            pbLevel.setProgress(percent);
            tvLevel.setText(percent + " %");
        }
    };

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        ViewCompat.setOnApplyWindowInsetsListener(findViewById(android.R.id.content), (v, insets) -> {
            Insets bars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(bars.left, bars.top, bars.right, bars.bottom);
            return insets;
        });

        tvInfo = findViewById(R.id.tvInfo);
        tvLevel = findViewById(R.id.tvLevel);
        pbLevel = findViewById(R.id.pbLevel);

        ContextCompat.registerReceiver(this, batteryReceiver,
                new IntentFilter(Intent.ACTION_BATTERY_CHANGED),
                ContextCompat.RECEIVER_EXPORTED);
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        unregisterReceiver(batteryReceiver);
    }
}