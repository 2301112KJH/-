package com.example.report1sender;

import android.content.BroadcastReceiver;
import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.os.Bundle;
import android.widget.Button;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.content.ContextCompat;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

public class MainActivity extends AppCompatActivity {

    static final String ACTION = "com.example.broadcast.FILE_DOWNLOADED";

    BroadcastReceiver dynamicReceiver = new BroadcastReceiver() {
        @Override
        public void onReceive(Context context, Intent intent) {
            String fileName = intent.getStringExtra("fileName");
            Toast.makeText(context,
                    "동적 Receiver : FILE_DOWNLOADED\n" + fileName,
                    Toast.LENGTH_LONG).show();
        }
    };

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        ViewCompat.setOnApplyWindowInsetsListener(findViewById(android.R.id.content), (v, insets) -> {
            Insets bars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(bars.left, bars.top, bars.right, bars.bottom);
            return insets;
        });

        ContextCompat.registerReceiver(this, dynamicReceiver,
                new IntentFilter(ACTION), ContextCompat.RECEIVER_NOT_EXPORTED);

        Button btnDynamic = findViewById(R.id.btnDynamic);
        Button btnStatic = findViewById(R.id.btnStatic);

        btnDynamic.setOnClickListener(v -> {
            Intent intent = new Intent(ACTION);
            intent.setPackage(getPackageName());
            intent.putExtra("fileName", "Kyungbok.png");
            sendBroadcast(intent);
        });

        btnStatic.setOnClickListener(v -> {
            Intent intent = new Intent(ACTION);
            intent.setComponent(new ComponentName(
                    "com.example.report1receiver",
                    "com.example.report1receiver.MyReceiver"));
            intent.putExtra("fileName", "경복대학교.png");
            sendBroadcast(intent);
        });
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        unregisterReceiver(dynamicReceiver);
    }
}