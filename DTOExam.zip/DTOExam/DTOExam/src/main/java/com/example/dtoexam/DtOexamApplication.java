package com.example.dtoexam;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class DtOexamApplication {

    public static void main(String[] args) {
        SpringApplication.run(DtOexamApplication.class, args);
    }

}
