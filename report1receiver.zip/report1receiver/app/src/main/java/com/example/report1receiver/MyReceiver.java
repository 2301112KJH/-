package com.example.report1receiver;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.widget.Toast;

public class MyReceiver extends BroadcastReceiver {
    @Override
    public void onReceive(Context context, Intent intent) {
        String fileName = intent.getStringExtra("fileName");

        SharedPreferences pref = context.getSharedPreferences("data", Context.MODE_PRIVATE);
        pref.edit().putString("fileName", fileName).apply();

        Toast.makeText(context,
                "정적 Receiver : " + intent.getAction() + "\n" + fileName,
                Toast.LENGTH_LONG).show();
    }
}