package com.example.report1receiver;

import android.content.Context;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.widget.TextView;
import androidx.appcompat.app.AppCompatActivity;

public class MainActivity extends AppCompatActivity {
    TextView tvMessage;
    SharedPreferences pref;

    SharedPreferences.OnSharedPreferenceChangeListener listener =
            (sharedPreferences, key) -> {
                if ("fileName".equals(key)) {
                    showFileName();
                }
            };

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        tvMessage = findViewById(R.id.tvMessage);
        pref = getSharedPreferences("data", Context.MODE_PRIVATE);
    }

    @Override
    protected void onResume() {
        super.onResume();
        showFileName();
        pref.registerOnSharedPreferenceChangeListener(listener);
    }

    @Override
    protected void onPause() {
        super.onPause();
        pref.unregisterOnSharedPreferenceChangeListener(listener);
    }

    private void showFileName() {
        String fileName = pref.getString("fileName", null);
        if (fileName != null) {
            tvMessage.setText(fileName);
        }
    }
}