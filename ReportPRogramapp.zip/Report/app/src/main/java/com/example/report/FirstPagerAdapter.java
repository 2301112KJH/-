package com.example.report;

import androidx.annotation.NonNull;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentActivity;
import androidx.viewpager2.adapter.FragmentStateAdapter;

public class FirstPagerAdapter extends FragmentStateAdapter {

    int[] colors = {
            0xFFAB63C9,
            0xFF4CAF50,
            0xFF2196F3,
            0xFFFF9800
    };

    public FirstPagerAdapter(@NonNull FragmentActivity activity) {
        super(activity);
    }

    @NonNull
    @Override
    public Fragment createFragment(int position) {
        return ColorFragment.newInstance(
                position,
                colors[position],
                (position + 1) + " Page"
        );
    }

    @Override
    public int getItemCount() {
        return colors.length;
    }
}