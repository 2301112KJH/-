package com.example.report;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.LinearLayout;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;
import androidx.viewpager2.widget.ViewPager2;

import com.google.android.material.tabs.TabLayout;
import com.google.android.material.tabs.TabLayoutMediator;

public class MainActivity extends AppCompatActivity {

    LinearLayout first, second;
    CheckBox chkNew;
    Button btnToggle;
    TextView txtTitle;
    ViewPager2 viewPager2, viewPager;
    TabLayout tabLayout;

    boolean vertical = false;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        first = findViewById(R.id.first);
        second = findViewById(R.id.second);
        chkNew = findViewById(R.id.chkNew);
        btnToggle = findViewById(R.id.btnToggle);
        txtTitle = findViewById(R.id.txtTitle);
        viewPager2 = findViewById(R.id.viewPager2);
        viewPager = findViewById(R.id.viewPager);
        tabLayout = findViewById(R.id.tabLayout);

        viewPager2.setAdapter(new FirstPagerAdapter(this));
        viewPager.setAdapter(new TabPagerAdapter(this));

        TabLayoutMediator mediator = new TabLayoutMediator(
                tabLayout, viewPager,
                (tab, position) -> {

                    switch (position) {
                        case 0:
                            tab.setText("첫번째TAB");
                            break;

                        case 1:
                            tab.setText("두번째TAB");
                            break;

                        case 2:
                            tab.setText("세번째TAB");
                            break;

                        case 3:
                            tab.setText("네번째TAB");
                            break;
                    }
                });

        mediator.attach();

        chkNew.setOnCheckedChangeListener((buttonView, isChecked) -> {
            if (isChecked) {
                first.setVisibility(View.GONE);
                second.setVisibility(View.VISIBLE);
                txtTitle.setText("Report02");
            } else {
                second.setVisibility(View.GONE);
                first.setVisibility(View.VISIBLE);
                txtTitle.setText("ViewPager2");
            }
        });

        btnToggle.setOnClickListener(v -> {
            vertical = !vertical;

            if (vertical) {
                viewPager2.setOrientation(
                        ViewPager2.ORIENTATION_VERTICAL);
                btnToggle.setText("세로로 슬라이드");
            } else {
                viewPager2.setOrientation(
                        ViewPager2.ORIENTATION_HORIZONTAL);
                btnToggle.setText("가로로 슬라이드");
            }
        });
    }
}