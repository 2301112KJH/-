package com.example.report;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.PopupMenu;
import android.widget.TextView;
import android.view.Gravity;

import androidx.appcompat.app.AppCompatActivity;
import androidx.viewpager2.widget.ViewPager2;

import com.google.android.material.tabs.TabLayout;
import com.google.android.material.tabs.TabLayoutMediator;

public class MainActivity extends AppCompatActivity {

    LinearLayout first, second;
    Button btnToggle;
    TextView txtTitle, btnMenu;

    ViewPager2 viewPager2, viewPager;
    TabLayout tabLayout;

    boolean vertical = false;
    boolean newSlide = false;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        first = findViewById(R.id.first);
        second = findViewById(R.id.second);
        btnToggle = findViewById(R.id.btnToggle);
        txtTitle = findViewById(R.id.txtTitle);
        btnMenu = findViewById(R.id.btnMenu);
        viewPager2 = findViewById(R.id.viewPager2);
        viewPager = findViewById(R.id.viewPager);
        tabLayout = findViewById(R.id.tabLayout);

        viewPager2.setAdapter(new FirstPagerAdapter(this));
        viewPager.setAdapter(new TabPagerAdapter(this));

        TabLayoutMediator mediator = new TabLayoutMediator(
                tabLayout,
                viewPager,
                (tab, position) -> {

                    TextView tabView = new TextView(this);

                    String[] icons = {
                            "⌂",
                            "▢",
                            "▤",
                            "⚙"
                    };

                    String[] names = {
                            "HOME",
                            "CHATTING",
                            "NEWS",
                            "SETTING"
                    };

                    tabView.setText(icons[position] + "\n" + names[position]);
                    tabView.setGravity(Gravity.CENTER);
                    tabView.setTextSize(12);

                    tab.setCustomView(tabView);
                }
        );

        mediator.attach();

        btnMenu.setOnClickListener(v -> {

            PopupMenu popup = new PopupMenu(
                    MainActivity.this, btnMenu);

            popup.getMenu().add(
                    0, 1, 0, "새로운 슬라이드"
            ).setCheckable(true).setChecked(newSlide);

            popup.setOnMenuItemClickListener(item -> {

                newSlide = !newSlide;
                item.setChecked(newSlide);

                if (newSlide) {
                    first.setVisibility(View.GONE);
                    second.setVisibility(View.VISIBLE);
                } else {
                    second.setVisibility(View.GONE);
                    first.setVisibility(View.VISIBLE);
                }

                return true;
            });

            popup.show();
        });

        btnToggle.setOnClickListener(v -> {

            vertical = !vertical;

            if (vertical) {

                viewPager2.setOrientation(
                        ViewPager2.ORIENTATION_VERTICAL);

                btnToggle.setText("세로로 슬라이드");

            } else {

                viewPager2.setOrientation(
                        ViewPager2.ORIENTATION_HORIZONTAL);

                btnToggle.setText("가로로 슬라이드");
            }
        });
    }
}
